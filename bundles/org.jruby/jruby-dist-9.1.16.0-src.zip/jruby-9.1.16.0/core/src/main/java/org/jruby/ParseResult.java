package org.jruby;

public interface ParseResult {
}
