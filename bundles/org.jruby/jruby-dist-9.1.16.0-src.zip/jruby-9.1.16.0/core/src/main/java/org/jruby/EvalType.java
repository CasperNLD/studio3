package org.jruby;

public enum EvalType {
    NONE, BINDING_EVAL, INSTANCE_EVAL, MODULE_EVAL
};
