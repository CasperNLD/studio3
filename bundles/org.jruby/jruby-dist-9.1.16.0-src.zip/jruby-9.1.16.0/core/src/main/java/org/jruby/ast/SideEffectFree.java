package org.jruby.ast;

/**
 * Created by enebo on 9/26/15.
 */
public interface SideEffectFree {
}
