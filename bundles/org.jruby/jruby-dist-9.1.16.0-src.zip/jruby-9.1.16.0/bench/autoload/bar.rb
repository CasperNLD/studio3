# for autoload Foo::Bar

class Foo
  module Bar
    X = 1
  end
end
